const $ = (id) => document.getElementById(id);
const form = $("reportForm");
const details = $("details");
const count = $("charCount");
const notice = $("notice");
const player = $("player");
let audioUrl = null;

details.addEventListener("input", () => count.textContent = `${details.value.length} / 1800`);

form.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const reason = $("reason").value;
  const phone = $("phone").value.trim();
  const date = $("date").value || "Non précisée";
  const description = details.value.trim();
  const subject = `Demande d’assistance WhatsApp — ${reason}`;
  const body = [
    "Bonjour l’équipe d’assistance WhatsApp,",
    "",
    "Je vous contacte au sujet de mon compte.",
    `Motif : ${reason}`,
    `Numéro concerné : ${phone}`,
    `Date du problème : ${date}`,
    "",
    "Description :",
    description,
    "",
    "Merci de bien vouloir examiner ma demande.",
    "Cordialement."
  ].join("\n");
  const mailto = `mailto:android@support.whatsapp.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  notice.textContent = "Ton application e-mail va s’ouvrir avec un brouillon. Vérifie l’adresse du destinataire et le contenu avant d’envoyer. Si aucune application ne s’ouvre, utilise le contact officiel WhatsApp.";
  notice.classList.add("show");
  window.location.href = mailto;
});

$("accent").addEventListener("input", (e) => setAccent(e.target.value));
function setAccent(value) {
  document.documentElement.style.setProperty("--accent", value);
  $("accentValue").textContent = value.toUpperCase();
  $("accent").value = value;
}
$("resetColor").addEventListener("click", () => setAccent("#00f5a0"));
$("brightness").addEventListener("input", (e) => document.documentElement.style.setProperty("--brightness", Number(e.target.value) / 100));

$("bgUpload").addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) return alert("Choisis un fichier image.");
  const reader = new FileReader();
  reader.onload = () => document.documentElement.style.setProperty("--custom-bg", `url("${reader.result}")`);
  reader.readAsDataURL(file);
});
$("clearBg").addEventListener("click", () => {
  document.documentElement.style.removeProperty("--custom-bg");
  $("bgUpload").value = "";
});
$("toggleMotion").addEventListener("click", (e) => {
  document.body.classList.toggle("reduce-motion");
  e.currentTarget.textContent = document.body.classList.contains("reduce-motion") ? "Activer les animations" : "Réduire les animations";
});
$("audioUpload").addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("audio/")) return alert("Choisis un fichier audio.");
  if (audioUrl) URL.revokeObjectURL(audioUrl);
  audioUrl = URL.createObjectURL(file);
  player.src = audioUrl;
  player.volume = Number($("volume").value) / 100;
  $("audioToggle").disabled = false;
  $("audioToggle").textContent = "▶ Lire";
});
$("volume").addEventListener("input", (e) => player.volume = Number(e.target.value) / 100);
$("audioToggle").addEventListener("click", async () => {
  if (!player.src) return;
  if (player.paused) {
    try { await player.play(); $("audioToggle").textContent = "Ⅱ Pause"; }
    catch { $("audioToggle").textContent = "Lecture bloquée"; }
  } else {
    player.pause();
    $("audioToggle").textContent = "▶ Lire";
  }
});
player.addEventListener("ended", () => $("audioToggle").textContent = "▶ Lire");
