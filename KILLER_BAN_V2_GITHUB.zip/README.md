# KILLER BAN — Report Center V2

Site statique, utilisable sur téléphone ou ordinateur.

## Fonctionnalités
- Formulaire de préparation d'une demande au support WhatsApp.
- Brouillon e-mail créé localement via `mailto:` ; l'utilisateur vérifie et envoie lui-même.
- Personnalisation de la couleur néon, de la luminosité, de l'image de fond et des animations.
- Lecture manuelle d'un fichier audio choisi localement.
- Interface responsive mobile/ordinateur.

## Lancer
Ouvre `index.html` dans un navigateur. Pour publier, importe le dossier dans un hébergeur statique (par exemple Vercel).

## Important
Ce site n'est pas affilié à WhatsApp, ne peut pas bannir de compte et n'envoie aucun signalement automatiquement. Il ne collecte ni ne stocke les informations du formulaire. Utilise le formulaire uniquement pour des informations exactes et des demandes légitimes.
